package conect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conek {
    private static Connection mysqlconfig;;
    public static Connection getConnection() throws SQLException {
        try{ 
            String url="jdbc:mysql://localhost:3306/project";
            String user="root";
            String pass=""; 
        DriverManager.registerDriver(new com.mysql.jdbc.Driver());
        mysqlconfig=DriverManager.getConnection(url,user,pass);
        }catch (Exception e){
            System.err.println("Koneksi Gagal"+e.getMessage());
        }
        return mysqlconfig;
        }
    public static Object GetConnection() {
        throw new UnsupportedOperationException("Not supported yet."); 
// Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
